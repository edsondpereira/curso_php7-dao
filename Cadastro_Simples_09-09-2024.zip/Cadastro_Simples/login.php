<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro Simples em PHP</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="estilos.css">
</head>

<body>
    <div class="container">
        <div id="login">
            <h3 class="text-center  text-sucess">CADASTRO SIMPLES EM PHP</h3>
            <h3 class="text-center  text-danger">Acesso ao Sistema</h3>
            <form name="cadastro" method="post" action="ValidarLogin.php">
                <table>
                    <tr>
                        <td><label>E-mail:</td>
                        <td><input type="text" name="email" size="30" maxlength="30"></td>
                    </tr>
                    <tr>
                        <td><label>Senha:</td>
                        <td><input type="password" name="senha" size="20" maxlength="20"></td>
                    </tr>
                    <tr>
                        <td colspan="2" align="center">
                            <input type="submit" name="acessar" value="Acessar" class="btn btn-primary">
                        </td>
                    </tr>
                </table>
            </form>
        </div>
    </div>
</body>

</html>