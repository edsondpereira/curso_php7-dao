<?php
session_start();
if (isset($_SESSION["email"])) {
    // se a sessão foi iniciada (informado o email e a senha)
    $email  =   $_SESSION["email"];
    echo "<p>Seja bem-vindo " . $email . "</p>";
} else {
    echo "Você não fez o login!";
    echo "<meta http-equiv='refresh' content='3;url=login.php'>";
}
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro Simples em PHP</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>

<body>
    <div class="container">
        <h3 class="text-center text-primary">CADASTRO SIMPLES EM PHP</h3>
        <p><a href="logout.php">Sair</a></p>
    </div>
</body>

</html>