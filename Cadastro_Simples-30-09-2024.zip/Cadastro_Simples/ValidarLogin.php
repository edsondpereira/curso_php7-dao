<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro Simples - PHP - Validação do Login</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>
    <h3 class="text-center text-primary">Validação do Login</h3>
    <?php        
        // As duas linhas abaixo, recupera os dados do formulário, e armazena nas variáveis
        $email  =   $_POST["email"];
        $senha  =   $_POST["senha"];
        $MensagemErro = ""; // Armazena as mensagens de erro
        $erro = 0; // Se existir algum erro, adiciona +1 nesta variável
        if(empty($email)) // Se o email não foi digitado
        {
            $MensagemErro = "Por favor... informe o E-mail!";
            $erro++;
        }
        if(empty($senha)) {
            $MensagemErro .= "Por favor... informe a Senha!";
            $erro++;
        }
        if($erro > 0) { // Se o e-mail e/ou a senha não foi digitado, exibe mensagem de erro
            echo $MensagemErro;
            echo "<p><a href='login.php'>Voltar</p>";
        }
        if($email == "edson@gmail.com" && $senha=="1234") // Se o email e a senha estiverem corretos
        {
            // Armazena o email digitado no formulário, na variável da sessão
            session_start(); // Inicializa a sessão
            $_SESSION["email"]   =   $email;
            echo "<p>Acesso concedido!<br>";
            echo "<a href='principal.php'>Clique aqui para Acessar</a>";            
        }
        else {
            echo "<p>E-mail ou Senha Inválido</p>";
            echo "<p>Acesso negado!<br>";
            echo "<a href='login.php'>Clique aqui para retornar</a>"; 
        }
    ?>
</body>
</html>