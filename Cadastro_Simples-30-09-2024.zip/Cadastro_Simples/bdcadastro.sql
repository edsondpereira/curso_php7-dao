-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 30/09/2024 às 13:22
-- Versão do servidor: 10.4.28-MariaDB
-- Versão do PHP: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `bdcadastro`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `tbclientes`
--

CREATE TABLE `tbclientes` (
  `codCliente` int(4) NOT NULL,
  `Nome` varchar(50) NOT NULL,
  `Cidade` varchar(30) NOT NULL,
  `uf` char(2) DEFAULT NULL,
  `Email` varchar(30) NOT NULL,
  `CPF` varchar(14) NOT NULL,
  `Contato` varchar(14) NOT NULL,
  `Situacao` char(1) DEFAULT 'A'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `tbclientes`
--

INSERT INTO `tbclientes` (`codCliente`, `Nome`, `Cidade`, `uf`, `Email`, `CPF`, `Contato`, `Situacao`) VALUES
(1, 'Elisio Silva', 'Bebedouro', NULL, 'elisio@gmail.com', '022.343.234-11', '(17) 90900-112', 'A'),
(2, 'Maria Ferreira', 'Bebedouro', NULL, 'maria.gmail.com', '342.123.126-33', '(17) 90909-342', 'A'),
(3, 'Horácio da SIlva', 'Bebedouro', 'SP', 'edinaldo@yahoo.com.br', '456.465.465-46', '(17) 31321-321', 'A');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `tbclientes`
--
ALTER TABLE `tbclientes`
  ADD PRIMARY KEY (`codCliente`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `tbclientes`
--
ALTER TABLE `tbclientes`
  MODIFY `codCliente` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
