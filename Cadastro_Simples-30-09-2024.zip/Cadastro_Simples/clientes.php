<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro Simples em PHP</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <script src="js/jquery.js"></script>
    <script src="js/jquery.mask.js"></script>
</head>

<body>
    <script>
        $(function() {
            $(".fone").mask("(00) 00000-0000", {placeholder: "(00) 00000-0000"});
            $(".cep").mask("00000-000", {placeholder: "00000-000"});
            $(".cpf").mask("000.000.000-00", {placeholder: "000.000.000-00"});
        })
    </script>
    <div class="container">
        <h3 class="text-center text-primary">CADASTRO SIMPLES EM PHP UTILIZANDO JQUERY</h3>
        <form name="cadastro" method="post" action="">
            <table>
                <tr>
                    <td><label>Nome:</label></td>
                    <td><input type="text" name="nome" size="60" maxlength="80" placeholder="Informe o nome completo" required></td>
                </tr>
                <tr>
                    <td><label>Cidade:</label></td>
                    <td><input type="text" name="cidade" size="30" maxlength="30" requireds></td>
                </tr>
                <tr>
                    <td><label>UF:</label></td>
                    <td>
                        <select name="uf">
                            <option value="SP">SP</option>
                            <option value="RJ">RJ</option>
                            <option value="MG">MG</option>
                            <option value="DF">DF</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td><label>Contato:</label></td>
                    <td><input type="text" name="contato" size="15" maxlength="15" required class="fone"></td>
                </tr>
                <tr>
                    <td><label>CPF:</td>
                    <td><input type="cpf" name="cpf" size="14" maxlength="14" required class="cpf"></td>
                </tr>
                <tr>
                    <td><label>E-mail:</label></td>
                    <td><input type="email" name="email" size="30" maxlength="30" required></td>
                </tr>
                <tr>
                    <td colspan="2" align="center">
                        <input type="submit" name="inserir" value="Inserir" class="btn btn-primary">
                    </td>
                </tr>
            </table>
        </form>
        <?php
            if(isset($_POST["inserir"])) // Se clicou no botão inserir
            {
                require "conexao.php";
                $nome   =   $_POST["nome"];
                $cidade =   $_POST["cidade"];
                $uf     =   $_POST["uf"];
                $email  =   $_POST["email"];
                $contato=   $_POST["contato"];
                $cpf    =   $_POST["cpf"];
                $sql="INSERT INTO tbclientes(codcliente,nome,cidade,uf,email,contato,cpf)";
                $sql.=" VALUES(null,'$nome','$cidade','$uf','$email','$contato','$cpf')";
                mysqli_query($conexao, $sql) or die(mysqli_error($conexao));
                echo "<script>alert('Cliente cadastrado com sucesso!')</script>";
            }
        ?>
    </div>
</body>

</html>