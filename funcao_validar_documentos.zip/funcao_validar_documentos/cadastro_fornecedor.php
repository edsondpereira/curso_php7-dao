<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Fornecedor</title>
</head>

<body>
    <h3>CADASTRO DE FORNECEDORES EM PHP</h3>
    <form name="fornecedores" method="post" action="">
        <table>
            <tr>
                <td><label>Razão Social:</label></td>
                <td><input type="text" name="RazaoSocial" size="40" maxlength="60" placeholder="Informe a Razão Social" required></td>
            </tr>
            <tr>
                <td><label>Nome Fantasia:</label></td>
                <td><input type="text" name="NomeFantasia" size="40" maxlength="60" required></td>
            </tr>
            <tr>
                <td><label>Cidade:</label></td>
                <td><input type="text" name="cidade" size="30" maxlength="30" required></td>
            </tr>
            <tr>
                <td><label>CNPJ:</label></td>
                <td><input type="text" name="cnpj" size="18" maxlength="18" required></td>
            </tr>
            <tr>
                <td><label>Inscrição Estadual:</label></td>
                <td><input type="text" name="rg" size="15" maxlength="15" required></td>
            </tr>
            <tr>
                <td><label>Contato:</label></td>
                <td><input type="text" name="contato" size="14" maxlength="14" required></td>
            </tr>
            <tr>
                <td colspan="2" align="center"><input type="submit" name="enviar" value="Enviar"></td>
            </tr>
        </table>
    </form>
    <?php
    if (isset($_POST["enviar"])) {
        require "validar.php";
        // Validação do CNPJ
        echo "<hr>";
        $cnpj = $_POST["cnpj"];
        if (validaCPF($cnpj)) {
            echo "CNPJ Válido";
        } else {
            echo "CNPJ Inválido";
        }
    }
    ?>
</body>

</html>