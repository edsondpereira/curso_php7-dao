<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Validação de CPF e CNPJ</title>
</head>
<body>
    <h3>Validação de CPF e CNPJ</h3>
    <a href="cadastro_clientes.php">Cadastro de Clientes</a> |
    <a href="cadastro_fornecedor.php">Cadastro de Fornecedores</a>
</body>
</html>