CREATE database bdcomponente

USE bdcomponente

CREATE TABLE tbcomponente
(
codigo INT(4) AUTO_INCREMENT PRIMARY KEY,
curso VARCHAR(60) NOT NULL
componente VARCHAR(80) NOT NULL
)